<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>uccfstext</title>
    <style>
        p{
            color: red;
            display: flex;
            justify-content: center;
            margin: 2em;
        }
        strong{
            color: #000;
        }
        a{
            text-decoration: none;
            color: purple;
        }
    </style>
</head>
<body>

<p>Sorry, the password reset token has expired. you may need to get a new reset token or <strong>&nbsp; <a href="mailto:support@uccfstext.com">contact support@uccfstext.com</a></strong> </p>
    
</body>
</html>